package com.example.trinity_spangler_weight_tracking_app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

// Handles the app's SQLite database
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "WeightTracker.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creates database tables the first time the app runs
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE, " +
                "password TEXT)");

        db.execSQL("CREATE TABLE weight_entries (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "date TEXT, " +
                "weight REAL)");

        db.execSQL("CREATE TABLE goal_weight (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "goal REAL)");
    }

    // Rebuilds tables if database version changes
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS weight_entries");
        db.execSQL("DROP TABLE IF EXISTS goal_weight");
        onCreate(db);
    }

    // Adds a new user account
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("username", username);
        values.put("password", password);

        long result = db.insert("users", null, values);
        return result != -1;
    }

    // Checks username and password during login
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM users WHERE username = ? AND password = ?",
                new String[]{username, password}
        );

        boolean exists = cursor.getCount() > 0;
        cursor.close();

        return exists;
    }

    // Adds a new weight entry
    public boolean addWeightEntry(String date, double weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("date", date);
        values.put("weight", weight);

        long result = db.insert("weight_entries", null, values);
        return result != -1;
    }

    // Saves a goal weight
    public boolean saveGoalWeight(double goal) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.delete("goal_weight", null, null);

        ContentValues values = new ContentValues();
        values.put("goal", goal);

        long result = db.insert("goal_weight", null, values);
        return result != -1;
    }

    // Gets all saved weight entries
    public Cursor getAllWeightEntries() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM weight_entries ORDER BY id DESC", null);
    }

    // Gets the saved goal weight
    public double getGoalWeight() {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT goal FROM goal_weight LIMIT 1", null);

        double goal = 0;

        if (cursor.moveToFirst()) {
            goal = cursor.getDouble(0);
        }

        cursor.close();
        return goal;
    }

    // Deletes one weight entry by its ID
    public boolean deleteWeightEntry(int id) {
        SQLiteDatabase db = this.getWritableDatabase();

        int result = db.delete(
                "weight_entries",
                "id = ?",
                new String[]{String.valueOf(id)}
        );

        return result > 0;
    }

}