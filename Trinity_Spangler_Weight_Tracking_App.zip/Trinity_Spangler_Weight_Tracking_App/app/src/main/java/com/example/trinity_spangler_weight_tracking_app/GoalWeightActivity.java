package com.example.trinity_spangler_weight_tracking_app;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class GoalWeightActivity extends AppCompatActivity {

    // Input field used to enter a new goal weight
    EditText editTextGoalWeight;
    // Buttons for saving a goal weight or returning to the dashboard
    Button buttonSaveGoal, buttonBackGoal;
    // Database helper used to interact with SQLite
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Enables edge-to-edge display on modern Android devices
        EdgeToEdge.enable(this);

        // Loads the Goal Weight screen layout
        setContentView(R.layout.activity_goal_weight);

        // Connect Java variables to the XML screen components
        editTextGoalWeight = findViewById(R.id.editTextGoalWeight);
        buttonSaveGoal = findViewById(R.id.buttonSaveGoal);
        buttonBackGoal = findViewById(R.id.buttonBackGoal);

        // Creates a connection to the SQLite database
        databaseHelper = new DatabaseHelper(this);

        // Saves the user's goal weight to the database
        buttonSaveGoal.setOnClickListener(v -> {
            String goalText = editTextGoalWeight.getText().toString().trim();

            // Checks that a goal weight was entered
            if (goalText.isEmpty()) {
                Toast.makeText(this, "Please enter a goal weight", Toast.LENGTH_SHORT).show();
            } else {
                double goal = Double.parseDouble(goalText);

                boolean saved = databaseHelper.saveGoalWeight(goal);

                if (saved) {

                    // Goal weight was successfully saved
                    Toast.makeText(this, "Goal weight saved", Toast.LENGTH_SHORT).show();
                    finish();

                } else {

                    // Goal weight could not be saved
                    Toast.makeText(this, "Error saving goal weight", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Returns the user to the dashboard without making changes
        buttonBackGoal.setOnClickListener(v -> finish());
    }
}