package com.example.trinity_spangler_weight_tracking_app;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {

    // Displays the user's current goal and progress information
    TextView textViewGoalSummary;
    // Table used to display saved weight entries
    TableLayout tableWeightEntries;
    // Buttons for navigating to other parts of the application
    Button buttonAddWeight, buttonUpdateGoal, buttonSmsSettings;
    // Database helper used to interact with SQLite
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Enables edge-to-edge display on modern Android devices
        EdgeToEdge.enable(this);

        // Loads the Dashboard screen layout
        setContentView(R.layout.activity_dashboard);

        // Connect Java variables to the XML screen components
        textViewGoalSummary = findViewById(R.id.textViewGoalSummary);
        tableWeightEntries = findViewById(R.id.tableWeightEntries);
        buttonAddWeight = findViewById(R.id.buttonAddWeight);
        buttonUpdateGoal = findViewById(R.id.buttonUpdateGoal);
        buttonSmsSettings = findViewById(R.id.buttonSmsSettings);

        // Creates a connection to the SQLite database
        databaseHelper = new DatabaseHelper(this);

        // Opens the Add Weight screen
        buttonAddWeight.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, AddWeightActivity.class);
            startActivity(intent);
        });

        // Opens the Goal Weight screen
        buttonUpdateGoal.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, GoalWeightActivity.class);
            startActivity(intent);
        });

        // Opens the SMS permission/settings screen
        buttonSmsSettings.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, SmsPermissionActivity.class);
            startActivity(intent);
        });
    }

    // Refreshes dashboard information whenever the user returns to this screen
    @Override
    protected void onResume() {
        super.onResume();
        loadGoalSummary();
        loadWeightEntries();
    }

    // Loads the current goal and most recent weight entry
    // and calculates the remaining weight needed to reach the goal
    private void loadGoalSummary() {
        double goal = databaseHelper.getGoalWeight();
        Cursor cursor = databaseHelper.getAllWeightEntries();

        if (cursor.moveToFirst()) {
            double currentWeight = cursor.getDouble(cursor.getColumnIndexOrThrow("weight"));

            // Checks if the user has reached or exceeded their goal weight
            if (goal > 0) {
                double remaining = currentWeight - goal;

                if (remaining <= 0) {
                    textViewGoalSummary.setText(
                            "Current Goal: " + goal + " lbs\n" +
                                    "Current Weight: " + currentWeight + " lbs\n" +
                                    "Goal achieved!"
                    );
                } else {
                    textViewGoalSummary.setText(
                            "Current Goal: " + goal + " lbs\n" +
                                    "Current Weight: " + currentWeight + " lbs\n" +
                                    "Remaining: " + remaining + " lbs"
                    );
                }
            } else {
                textViewGoalSummary.setText(
                        "Current Goal: Not set\n" +
                                "Current Weight: " + currentWeight + " lbs\n" +
                                "Remaining: Not available"
                );
            }
        } else {
            textViewGoalSummary.setText(
                    "Current Goal: " + (goal > 0 ? goal + " lbs" : "Not set") + "\n" +
                            "Current Weight: Not set\n" +
                            "Remaining: Not available"
            );
        }

        cursor.close();
    }

    // Loads all saved weight entries into the dashboard table
    private void loadWeightEntries() {

        // Removes previously displayed rows before rebuilding the table
        while (tableWeightEntries.getChildCount() > 1) {
            tableWeightEntries.removeViewAt(1);
        }

        // Retrieves all saved weight entries from SQLite
        Cursor cursor = databaseHelper.getAllWeightEntries();

        // Creates a new table row for each saved weight entry
        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));
            double weight = cursor.getDouble(cursor.getColumnIndexOrThrow("weight"));

            TableRow row = new TableRow(this);

            TextView dateView = new TextView(this);
            dateView.setText(date);
            dateView.setPadding(8, 8, 8, 8);

            TextView weightView = new TextView(this);
            weightView.setText(weight + " lbs");
            weightView.setPadding(8, 8, 8, 8);

            // Creates a delete button for the selected weight entry
            Button deleteButton = new Button(this);
            deleteButton.setText("Delete");
            deleteButton.setTextSize(11);
            deleteButton.setTextColor(Color.parseColor("#B3261E"));
            deleteButton.setBackgroundColor(Color.TRANSPARENT);
            deleteButton.setAllCaps(false);
            deleteButton.setPadding(4, 2, 4, 2);

            // Deletes the selected weight entry
            deleteButton.setOnClickListener(v -> {
                boolean deleted = databaseHelper.deleteWeightEntry(id);

                if (deleted) {
                    Toast.makeText(this, "Entry deleted", Toast.LENGTH_SHORT).show();
                    loadGoalSummary();
                    loadWeightEntries();
                } else {
                    Toast.makeText(this, "Error deleting entry", Toast.LENGTH_SHORT).show();
                }
            });

            row.addView(dateView);
            row.addView(weightView);
            row.addView(deleteButton);

            // Adds the completed row to the dashboard table
            tableWeightEntries.addView(row);
        }

        // Closes the database cursor to free resources
        cursor.close();
    }
}