package com.example.trinity_spangler_weight_tracking_app;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class CreateAccountActivity extends AppCompatActivity {

    // Input fields for creating a new username and password
    EditText editTextNewUsername, editTextNewPassword;
    // Buttons for creating an account or returning to the login screen
    Button buttonSaveAccount, buttonBackToLogin;
    // Database helper used to interact with SQLite
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Enables edge-to-edge display on modern Android devices
        EdgeToEdge.enable(this);

        // Loads the Create Account screen layout
        setContentView(R.layout.activity_create_account);

        // Connect Java variables to the XML screen components
        editTextNewUsername = findViewById(R.id.editTextNewUsername);
        editTextNewPassword = findViewById(R.id.editTextNewPassword);
        buttonSaveAccount = findViewById(R.id.buttonSaveAccount);
        buttonBackToLogin = findViewById(R.id.buttonBackToLogin);

        // Creates a connection to the SQLite database
        databaseHelper = new DatabaseHelper(this);

        // Creates a new user account and stores it in the database
        buttonSaveAccount.setOnClickListener(v -> {
            String username = editTextNewUsername.getText().toString().trim();
            String password = editTextNewPassword.getText().toString().trim();

            // Checks that both fields contain data
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please create a username and password", Toast.LENGTH_SHORT).show();
            } else {
                boolean accountCreated = databaseHelper.addUser(username, password);

                if (accountCreated) {

                    // Account was successfully created
                    Toast.makeText(this, "Account created. Please log in.", Toast.LENGTH_SHORT).show();
                    finish();

                } else {

                    // Username already exists in the database
                    Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();

                }
            }
        });

        // Returns the user to the login screen without creating an account
        buttonBackToLogin.setOnClickListener(v -> finish());
    }
}