package com.example.trinity_spangler_weight_tracking_app;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsPermissionActivity extends AppCompatActivity {

    // Requests code used when asking for SMS permission
    private static final int SMS_PERMISSION_CODE = 100;

    Button buttonEnableSms, buttonNoThanksSms, buttonBackSms;
    TextView textSmsStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sms_permission);

        // Connects Java variables to the XML screen components
        buttonEnableSms = findViewById(R.id.buttonEnableSms);
        buttonNoThanksSms = findViewById(R.id.buttonNoThanksSms);
        buttonBackSms = findViewById(R.id.buttonBackSms);
        textSmsStatus = findViewById(R.id.textSmsStatus);

        // Show the current SMS permission status
        updatePermissionStatus();

        // Requests SMS permission from the user
        buttonEnableSms.setOnClickListener(v -> {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE
            );
        });

        // Allows the user to continue without allowing SMS notifications
        buttonNoThanksSms.setOnClickListener(v -> {
            Toast.makeText(this, "SMS notifications skipped", Toast.LENGTH_SHORT).show();
            finish();
        });

        // Returns the user to the dashboard
        buttonBackSms.setOnClickListener(v -> finish());
    }

    // Updates the permission status message shown on the screen
    private void updatePermissionStatus() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            textSmsStatus.setText("Current Permission Status: Granted");
        } else {
            textSmsStatus.setText("Current Permission Status: Not Granted");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        // Checks the user's response to the permission request
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // User allowed SMS permission
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                // User denied SMS permission
                Toast.makeText(this, "SMS permission denied. App will still work.", Toast.LENGTH_SHORT).show();
            }

            // Refresh the permission status that is shown on the screen
            updatePermissionStatus();
        }
    }
}