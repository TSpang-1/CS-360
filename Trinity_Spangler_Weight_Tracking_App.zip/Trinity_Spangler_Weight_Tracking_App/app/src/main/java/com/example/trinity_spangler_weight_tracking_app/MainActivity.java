package com.example.trinity_spangler_weight_tracking_app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // Input fields used for entering login credentials
    EditText editTextUsername, editTextPassword;

    // Buttons for logging in or creating a new account
    Button buttonLogin, buttonCreateAccount;

    // Database helper used to interact with SQLite
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Enables edge-to-edge display on modern Android devices
        EdgeToEdge.enable(this);

        // Loads the Login screen layout
        setContentView(R.layout.activity_login);

        // Connect Java variables to the XML screen items
        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        // Creates a connection to the SQLite database
        databaseHelper = new DatabaseHelper(this);

        // Validates the user's login credentials
        buttonLogin.setOnClickListener(v -> {
            String username = editTextUsername.getText().toString().trim();
            String password = editTextPassword.getText().toString().trim();

            // Checks that both username and password were entered
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter a username and password", Toast.LENGTH_SHORT).show();
            } else {

                // Verifies the username and password against the database
                boolean loginSuccess = databaseHelper.checkUser(username, password);

                if (loginSuccess) {

                    // Opens the Dashboard screen after a successful login
                    Intent intent = new Intent(MainActivity.this, DashboardActivity.class);
                    startActivity(intent);

                } else {

                    // Displays an error message if the login fails
                    Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Opens the Create Account screen
        buttonCreateAccount.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CreateAccountActivity.class);
            startActivity(intent);
        });
    }
}