package com.example.trinity_spangler_weight_tracking_app;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class AddWeightActivity extends AppCompatActivity {

    // Input fields for entering a weight and date
    EditText editTextWeight, editTextDate;
    // Buttons for saving or canceling a weight entry
    Button buttonSaveWeight, buttonCancelWeight;
    // Database helper used to interact with SQLite
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Enables edge-to-edge display on modern Android devices
        EdgeToEdge.enable(this);

        // Loads the Add Weight screen layout
        setContentView(R.layout.activity_add_weight);

        // Connects Java variables to the XML screen components
        editTextWeight = findViewById(R.id.editTextWeight);
        editTextDate = findViewById(R.id.editTextDate);
        buttonSaveWeight = findViewById(R.id.buttonSaveWeight);
        buttonCancelWeight = findViewById(R.id.buttonCancelWeight);

        // Creates a connection to the SQLite database
        databaseHelper = new DatabaseHelper(this);

        // Saves a new weight entry to the database
        buttonSaveWeight.setOnClickListener(v -> {
            String weightText = editTextWeight.getText().toString().trim();
            String date = editTextDate.getText().toString().trim();

            // Checks that both fields contain data
            if (weightText.isEmpty() || date.isEmpty()) {
                Toast.makeText(this, "Please enter a date and weight", Toast.LENGTH_SHORT).show();
            } else {
                double weight = Double.parseDouble(weightText);

                boolean saved = databaseHelper.addWeightEntry(date, weight);

                if (saved) {

                    // Entry was successfully added to the database
                    Toast.makeText(this, "Weight entry saved", Toast.LENGTH_SHORT).show();
                    finish();

                } else {

                    // Entry could not be saved
                    Toast.makeText(this, "Error saving weight entry", Toast.LENGTH_SHORT).show();

                }
            }
        });

        // Returns the user back to the dashboard without saving
        buttonCancelWeight.setOnClickListener(v -> finish());
    }
}